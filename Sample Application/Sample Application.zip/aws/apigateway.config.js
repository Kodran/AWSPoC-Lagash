'use strict';

var apigatewayEndpoints = {
    loginEndpoint: "https://b57ue8rto0.execute-api.us-east-2.amazonaws.com/dev/login",    
    registerUserEndpoint: "https://b57ue8rto0.execute-api.us-east-2.amazonaws.com/dev/user",
    getUserEndpoint: "https://b57ue8rto0.execute-api.us-east-2.amazonaws.com/dev/user"
};

exports.apiGatewayEndpoints = apigatewayEndpoints;