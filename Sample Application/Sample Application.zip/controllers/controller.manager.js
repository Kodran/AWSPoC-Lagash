const
	login = require('./login/login.controller'),
	user = require('./user/user.controller');

exports.login = login;
exports.user = user;
